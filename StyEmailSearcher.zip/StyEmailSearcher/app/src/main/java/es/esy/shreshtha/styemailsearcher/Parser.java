package es.esy.shreshtha.styemailsearcher;

import java.io.*;
import java.util.StringTokenizer;

/**
 * Created by Styler on 19-02-2017.
 * Program to convert plain english in to mail search attributes
 */
public class Parser {

    static String from, to, toDate, fromDate, hasAttachments, attachmentType, attachmentSize, attachmentName, subject, cc;
    //all 10 fields in which the text has to be broken

    static {
        from = to = toDate = fromDate = attachmentName = attachmentSize = attachmentType = subject = cc = "Any";
        hasAttachments="Yes";
        //initialisation of all the fields
    }

    int wordCount;                  //variable to store no of words
    String words[];            //str is the input line and words is an array which stores the words of the imput text line


    public void dataWriter(File file,String str) {
        input(str);                                                        //input method is called
        FileOutputStream fout=null;
        try {
            fout= new FileOutputStream(file,true);
            fout.write(str.getBytes());
            fout.write(("\nFrom "+from).getBytes());
            fout.write(("\nTo "+to).getBytes());
            fout.write(("\nFromDate "+fromDate).getBytes());
            fout.write(("\nToDate "+toDate).getBytes());
            fout.write(("\nHasAttachments "+hasAttachments).getBytes());
            fout.write(("\nAttachmentType "+attachmentType).getBytes());
            fout.write(("\nAttachmentSize "+attachmentSize).getBytes());
            fout.write(("\nAttachmentName "+attachmentName).getBytes());
            fout.write(("\nSubject "+subject).getBytes());
            fout.write(("\nCC "+cc).getBytes());
            fout.write("\n".getBytes());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally {
            try {
                if(fout!=null)
                    fout.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void input(String str) {                                                               // this method firstly inputs the text and then do the parsing part
        StringTokenizer s = new StringTokenizer(str);                                       // making tokens of the input string
        wordCount = s.countTokens();
        words = new String[wordCount];                                                      // storing them in array
        for (int i = 0; i < wordCount; i++) {
            words[i] = s.nextToken();
        }
        int fromCount,toCount;                                                              //fromCount and toCount are used for keeping count of from and to in the text
        fromCount=toCount=0;

        for (int i = 0; i <wordCount ; i++) {                                                //loop for parsing the text and give values in the required fields
            if("from".equalsIgnoreCase(words[i])&& fromCount==0)                               //checking for from
            {
                int k=1;
                from=words[i+1];
                while(k<wordCount-2 &&words[i+ ++k].equalsIgnoreCase("and"))                               //checking for more than one person in from field
                    from= from+" and "+words[i+k++ +1];
                fromCount++;
            }
            else if("to".equalsIgnoreCase(words[i])&&toCount==0)                               //checking for to
            {
                to=words[i+1];
                int k=1;
                while(k<wordCount-2 &&words[i+ ++k].equalsIgnoreCase("and"))                               //checking for more than one person in to field
                    to= to+" and "+words[i+k++ +1];
                toCount++;
            }
            else if("from".equalsIgnoreCase(words[i])&& fromCount==1)                               //checking for fromDate
            {
                fromDate=words[i+1].length()>3?words[i+1].substring(0,2):words[i+1].charAt(0) +" "+words[i+2]+" "+words[i+3];
            }
            else if("to".equalsIgnoreCase(words[i])&&toCount==1)                               //checking for toDate
            {
                toDate= words[i+1].length()>3?words[i+1].substring(0,2):words[i+1].charAt(0) +" "+words[i+2]+" "+words[i+3];
            }
            else if("during".equalsIgnoreCase(words[i]))                               //checking for fromDate and toDate
            {
                fromDate=words[i+1].length()>3?words[i+1].substring(0,2):words[i+1].charAt(0) +" "+words[i+2]+" "+words[i+3];
                toDate=words[i+5].length()>3?words[i+5].substring(0,2):words[i+5].charAt(0) +" "+words[i+6]+" "+words[i+7];
            }
            else if("between".equalsIgnoreCase(words[i]))                                          //checking for fromDate and toDate
            {
                fromDate=words[i+1].length()>3?words[i+1].substring(0,2):words[i+1].charAt(0) +" "+words[i+2]+" "+words[i+3];
                toDate=words[i+5].length()>3?words[i+5].substring(0,2):words[i+5].charAt(0) +" "+words[i+6]+" "+words[i+7];
            }
            else if("last".equalsIgnoreCase(words[i]))                                         //checking for fromDate and toDate
            {
                fromDate="Today - "+Float.parseFloat(words[i+1])*isMonthDayOrYear(words[i+2]);
                toDate="Today";
            }
            else if("since".equalsIgnoreCase(words[i]))                                            //checking for fromDate and toDate
            {
                fromDate="Today - "+Float.parseFloat(words[i+1])*isMonthDayOrYear(words[i+2]);
                toDate="Today";
            }
            else if("on".equalsIgnoreCase(words[i]))                                               //checking for fromDate and toDate
            {
                if(Character.isDigit(words[i+1].charAt(0)))
                    fromDate=toDate= words[i+1].length()>3?words[i+1].substring(0,2):words[i+1].charAt(0) +" "+words[i+2]+" "+words[i+3];
                else
                    subject = words[i+1];
            }
            else if("cc".equalsIgnoreCase(words[i]))                                               //checking for CC
            {
                cc=words[i+1];
                int k=1;
                while(k<wordCount-2 &&words[i+ ++k].equalsIgnoreCase("and"))
                    cc= cc+" and "+words[i+k++ +1];
            }
            else if("subject".equalsIgnoreCase(words[i]))                                          //checking for subject
            {
                subject=words[i+2];
            }
            else if("about".equalsIgnoreCase(words[i]))                                              //checking for subject
            {
                subject=words[i+1];
            }
            else if("regarding".equalsIgnoreCase(words[i]))                                              //checking for subject
            {
                subject=words[i+1];
            }
            else if(words[i].endsWith("mb")||words[i].endsWith("MB"))                                 //checking attachment size
            {
                attachmentSize=isLargerSmallerOrEqual(words[i-3])+ words[i-1]+"MB" ;
            }
            else if("attachments".equalsIgnoreCase(words[i])||"attachment".equalsIgnoreCase(words[i]))
            {
                hasAttachments="Yes";
            }
            else if("pdf".equalsIgnoreCase(words[i])||"pdfs".equalsIgnoreCase(words[i])||"xls".equalsIgnoreCase(words[i])||
                    "txt".equalsIgnoreCase(words[i])|| "ppt".equalsIgnoreCase(words[i])||"ppts".equalsIgnoreCase(words[i])||
                    "jpeg".equalsIgnoreCase(words[i])||"mp3".equalsIgnoreCase(words[i])||"mp4".equalsIgnoreCase(words[i])||
                    "doc".equalsIgnoreCase(words[i])||"docs".equalsIgnoreCase(words[i])||"jpg".equalsIgnoreCase(words[i]))
            {
                hasAttachments="Yes";
                attachmentType=words[i].length()==4&&words[i].charAt(3)=='s'?words[i].substring(0,3):words[i];
            }
            else if("documents".equalsIgnoreCase(words[i])||"presentations".equalsIgnoreCase(words[i])||"audios".equalsIgnoreCase(words[i])||
                    "videos".equalsIgnoreCase(words[i])|| "images".equalsIgnoreCase(words[i]))
            {
                hasAttachments="Yes";
                if(words[i].equals("document"))
                    attachmentType="doc/pdf/txt";
                else if(words[i].equals("presentations"))
                    attachmentType="ppt";
                else if(words[i].equals("audios"))
                    attachmentType="mp3/wav/ogg";
                else if(words[i].equals("videos"))
                    attachmentType="mp4/avi/3gp";
                else if(words[i].equals("images"))
                    attachmentType="jpg/tiff/bmp/png";
            }
        }
    }
    public int isMonthDayOrYear(String str)
    {
        if(str.equalsIgnoreCase("months"))
            return 30;
        else if(str.equalsIgnoreCase("year")||str.equalsIgnoreCase("years"))
            return 365;
        else return 1;
    }
    public char isLargerSmallerOrEqual(String str)
    {
        if(str.equalsIgnoreCase("larger"))
            return '>';
        else if(str.equalsIgnoreCase("smaller"))
            return '<';
        else
            return '=';
    }
}