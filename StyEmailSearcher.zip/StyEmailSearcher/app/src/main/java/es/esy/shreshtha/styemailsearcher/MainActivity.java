package es.esy.shreshtha.styemailsearcher;

import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends AppCompatActivity {
    Parser parse= new Parser();
    EditText et;
    Button b;
    File folder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
    File inFile = new File(folder, "Input.txt");
    File outFile = new File(folder, "Output.txt");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et= (EditText) findViewById(R.id.editText);
        b= (Button) findViewById(R.id.button2);
        b.setVisibility(View.INVISIBLE);
    }
    public void singleLineInput(View v)
    {
        parse.dataWriter(outFile,et.getText().toString().trim());
        Toast.makeText(MainActivity.this, "Output file generated", Toast.LENGTH_SHORT).show();
        b.setVisibility(View.VISIBLE);
    }
    public void readInput(View v) {
        String state = Environment.getExternalStorageState();
        if (state.equals(Environment.MEDIA_MOUNTED)) {

            FileInputStream fin = null;
            try {
                fin = new FileInputStream(inFile);
                InputStreamReader isr = new InputStreamReader(fin);
                BufferedReader reader = new BufferedReader(isr);
                String line;
                while ((line = reader.readLine()) != null) {
                    parse.dataWriter(outFile,line);
                }

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (fin != null)
                        fin.close();
                    Toast.makeText(MainActivity.this, "Output File Generated", Toast.LENGTH_SHORT).show();
                    b.setVisibility(View.VISIBLE);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } else {
            Toast.makeText(this, "Media is not mounted...Reboot your device", Toast.LENGTH_SHORT).show();
        }
    }
    public void showOutput(View v)
    {
        Intent in= new Intent(Intent.ACTION_EDIT);
        Uri uri=Uri.parse(folder+"/output.txt");
        in.setDataAndType(uri,"text/plain");
        startActivity(in);
    }
}